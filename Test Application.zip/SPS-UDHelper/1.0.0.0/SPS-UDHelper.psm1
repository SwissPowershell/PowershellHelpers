Enum UDHColor {
    Random = 0
    DodgerBlue = 0x1d6ff8
    Coral = 0xff7f50
    Gold = 0xffd700
    PaleGreen = 0x98fb98
    RosyBrown = 0xbc8f8f
    SlateGray = 0x708090
    Teal = 0x008080
    Chardonnay = 0xfaeccc
    DarkMagenta = 0x8b008b
    Khaki = 0xc0c080
    PeachPuff = 0xffda99
    SteelBlue = 0x4682b4
    Amber = 0xffbf00
    Rose = 0x8e4585
    Olive = 0x808000
    Crimson = 0xdc143c
    SandyBrown = 0xf4a460
    SlateBlue = 0x6a5acd
    OliveDrab = 0x6b8e23
    Sienna = 0xa0522d
    DarkOrchid = 0x9932cc
    Peru = 0xcd853f
    MediumSeaGreen = 0x3cb371
    IndianRed = 0xcd5c5c
    DarkSlateGray = 0x2f4f4f
    Chocolate = 0xd2691e
    MediumPurple = 0x9370db
    DarkOliveGreen = 0x556b2f
    FireBrick = 0xb22222
    DimGray = 0x696969
    Goldenrod = 0xdaa520
    MediumAquamarine = 0x66cdaa
    CadetBlue = 0x5f9ea0
    DarkGoldenrod = 0xb8860b
    MediumSlateBlue = 0x7b68ee
    DarkKhaki = 0xbdb76b
}

Function Get-UDHColor {
    [CMDLetBinding()]
    Param(
        [UDHColor] ${Color} = 'Random'
    )
    if ($Color -eq 'Random'){
        $AllColors = [Enum]::GetValues([UDHColor])
        "#$((([UDHColor]::$($AllColors[$(Get-Random -Minimum 1 -Maximum $AllColors.Length)])).ToString('X')).ToString().SubString(2))"
    }else{
        "#$(([UDHColor]::$color.ToString('X')).ToString().SubString(2))"
    }
    
}
Enum UDUToastType {
    Error
    Warning
    Information
}
Function New-UDUInputBox {
    # [Category("app/component")]
    # [Description("An input box")]
    # [DisplayName("InputBox")]
    Param(
            [String] ${id} = [GUID]::NewGuid().Guid,
            [String] ${Title} = 'Default Title',
            [String] ${Text} = 'Default Text',
            [String] ${PlaceHolder} = 'Default Placeholder',
            [String] ${ButtonText} = 'Click Me',
            [String] ${InputValidationRegex} = '',
            [Switch] ${AllowNullOrEmpty},
            [String] ${Avatar} = '',
            [String] ${OnClick} = ''
    )
    $ClearAction = New-UDIconButton -Icon (New-UDIcon -Icon 'trash') -OnClick {
        Set-UDElement -Id $id -Properties @{
            Value = ''
        }
    }
    if ([String]::IsNullOrWhiteSpace($Avatar)) {
        $UDCardHeader = New-UDCardHeader -Title $Title -Id "$($Id)-UDCardHeader" -Action $ClearAction
    }else{
        $UDCardHeader = New-UDCardHeader -Title $Title -Id "$($Id)-UDCardHeader" -Avatar (New-UDAvatar -Content { $Avatar } -Sx @{ backgroundColor = 'white';Color = 'black' }) -Action $ClearAction
    }
    $ScripBlockString = @"
`$__TextBoxvalue = Get-UDElement -Id `$Id -Property 'Value'
`$IsValid = `$True
if (-not [string]::IsNullOrWhiteSpace(`$InputValidationRegex)) {
    `$IsValid = `$__TextBoxvalue -match `$InputValidationRegex
}
if ((-not `$AllowNullOrEmpty) -and ([string]::IsNullOrWhiteSpace(`$__TextBoxvalue))) {
    Show-UDUToast -Type Error -Message "`$(`$Text) !!"
}elseif (-not `$IsValid) {
    Show-UDUToast -Type Warning -Message 'input is not valid !!'
}else{
    #Show-UDUToast -Type Information -Message "You clicked inputbox value is : `$(`$__TextBoxvalue)"
    & $OnClick
}
"@
    $OnClick = [scriptblock]::Create($ScripBlockString)
    $UDCardBody = New-UDCardBody -Content {
        New-UDElement -Tag 'div' -Content {
            New-UDTextbox -Id $Id -Label $Text -Placeholder $PlaceHolder
            New-UDButton -Id "$($Id)-UDCardButton" -Text $ButtonText -ClassName 'inputBoxButton' -OnClick $OnClick

        } -ClassName 'inputBoxDiv'
        
    }
    New-UDCard -Header $UDCardHeader -Body $UDCardBody -ClassName 'inputBoxCard' -id "$($id)-UDCard"
}
Function Show-UDUToast {
    [CmdLetBinding(DefaultParameterSetName='Custom')]
    Param(
        [Parameter(
            Mandatory,
            Position=0,
            ParameterSetName='ByType'
        )]
        [UDUToastType] ${Type},
        [Parameter(
            Mandatory,
            Position=0
        )] 
        [String] ${Message},
        [Parameter(
            Mandatory=$false,
            Position=1
        )]
        [Int32] ${Duration}=1000
    )
    if ($PScmdlet.ParameterSetName -eq 'ByType') {
        Switch ($Type) {
            'Error' {
                Show-UDToast -Message $Message -TransitionIn bounceInRight -Duration $Duration -MessageColor white -BackgroundColor Red -Icon (New-UDIcon -Icon 'exclamationcircle')
                Break
            }
            'Warning' {
                Show-UDToast -Message $Message -TransitionIn bounceInRight -Duration $Duration -MessageColor white -BackgroundColor Orange -Icon (New-UDIcon -Icon 'warning')
                Break
            }
            'Information' {
                Show-UDToast -Message $Message -TransitionIn bounceInRight -Duration $Duration -Icon (New-UDIcon -Icon 'info')
                Break
            }
        }
        
    }Else{
        Show-UDToast -Message $Message -TransitionIn bounceInRight -Duration $Duration
    }
}
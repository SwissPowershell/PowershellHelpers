﻿New-UDApp -Title 'PowerShell Universal' -Pages @(
    Get-UDPage -Name 'home'
    Get-UDPage -Name 'Icon List'
    Get-UDPage -Name 'TabbedIconList'
    Get-UDPage -Name 'TestFunct'
) -Stylesheets '/assets/default.css'
﻿New-UDPage -Url "/Icons" -Name "Icon List" -Content {
	$AllIcons = Find-UDIcon -Name * | Sort-Object
    $allIcons | out-file "c:\allicons.txt"
	$AllColors = @(
    "#1d6ff8",
    "#ff7f50",
    "#ffd700",
    "#98fb98",
    "#bc8f8f",
    "#708090",
    "#008080",
    "#faeccc",
    "#8b008b",
    "#c0c080",
    "#ffda99",
    "#4682b4",
    "#ffbf00",
    "#8e4585",
    "#808000",
    "#dc143c",
    "#f4a460",
    "#6a5acd",
    "#6b8e23",
    "#a0522d",
    "#9932cc",
    "#cd853f",
    "#3cb371",
    "#cd5c5c",
    "#2f4f4f",
    "#d2691e",
    "#9370db",
    "#556b2f",
    "#b22222",
    "#696969",
    "#daa520",
    "#66cdaa",
    "#5f9ea0",
    "#b8860b",
    "#7b68ee",
    "#bdb76b"
)


	New-UDStyle -Style 'margin: auto;display: block;' -Content {
		$CurrCount = 0
		ForEach ($Icon in $AllIcons){
			$Color = $AllColors[$CurrCount]
            # $Color = $AllColors[$(Get-Random -Minimum 0 -Maximum $AllColors.count)]
			$CurrCount++
			if ($CurrCount -eq $AllColors.count){$CurrCount = 0}
			$IconObject = $Icon | ConvertTo-Json
			New-UDButton -Icon (New-UDIcon -Icon $Icon) -Style @{ 
				Width = "200px";
				Height = "150px";
				BorderRadius = "8px";
				FontSize = "25px";
				Color = 'Black';
				BackgroundColor = $Color
			} -OnClick {
				Show-UDToast -Message "$($IconObject) - $($Color)" -TransitionIn bounceInRight -Duration 10000
			}
		}
	}
} -Description "List of PSU Icons" -Title "PSU Icons" -Icon @{
	id = 'e577d8d2-2aff-429f-905a-1eb1a6b9e865'
	type = 'icon'
}
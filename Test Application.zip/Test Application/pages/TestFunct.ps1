﻿
$OnClick = {Show-UDToast -Message "Clicked : [$__TextBoxValue]" -TransitionIn bounceInRight -Duration 1000 -Icon (New-UDIcon -Icon 'info')}
$PageContent = {
    $Splat = @{
        id = 'UDUInputBox'
        Avatar = '@'
        Title = 'Search Mailbox'
        Text =  'Please input valid mail'
        PlaceHolder = 'someone@contoso.com'
        ButtonText = 'Search'
        InputValidationRegex = '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        OnClick = $OnClick
    }
    New-UDUInputBox @Splat
}

New-UDPage -Url "/TestFunct" -Name "TestFunct" -Content $PageContent -Description "Test UD Functionalities" -Title "Test UD Functionalities" -Icon @{
    id   = 'df351470-ec3d-40df-9c4d-c4c70f0a1a66'
    type = 'icon'
}
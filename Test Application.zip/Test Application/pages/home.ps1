﻿New-UDPage -Url "/Home" -Name "Home" -Content {
New-UDTypography -text 'Welcome' -id 'WelcomeText' -align 'center'
New-UDAvatar -id '0a266cb6-a7c5-4335-836f-c2751383ecc6'
} -Icon @{
		id = '7070b70c-9949-4b03-a272-087c7ab7f0de'
		type = 'icon'
	} -Generated -Layout (
New-UDPageLayout -Large @(
	New-UDItemLayout -Id 'WelcomeText' -Row 17 -Column 0 -RowSpan 1 -ColumnSpan 6
	New-UDItemLayout -Id '0a266cb6-a7c5-4335-836f-c2751383ecc6' -Row 0 -Column 0 -RowSpan 1 -ColumnSpan 1
) -Medium @(
) -Small @(
) -ExtraSmall @(
) -ExtraExtraSmall @(
	)
)